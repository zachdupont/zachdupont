#!/bin/bash

# Command to run when a Bluetooth device connects
ETHERWOKE_CMD="sudo etherwake -i eth0 10:7c:61:4a:08:d0 && sudo systemctl stop bluetooth"

echo "Starting Bluetooth monitor..."

while true; do
    # Monitor Bluetooth events
    bluetoothctl --monitor | while read -r line; do
        echo "Monitoring: $line"  # Debug output
        if [[ "$line" =~ "Connected: yes" ]]; then
            echo "Controller connected."
            eval $ETHERWOKE_CMD
            # Start a timer for 5 minutes
            for ((i=0; i<12; i++)); do
                sleep 25  # Check every 25 seconds (5 minutes = 12 * 25 seconds)
                # Check if the IP address is reachable
                if ! ping -c 1 192.168.1.2 > /dev/null 2>&1; then
                    echo "Gaming PC is offline."
                    # If offline for more than 5 minutes, start Bluetooth and monitor again
                    if [[ $i -eq 11 ]]; then
                        echo "Starting Bluetooth service..."
                        sudo systemctl start bluetooth
                        echo "Restarting Bluetooth monitor..."
                        break  # Exit the inner while to restart monitoring
                    fi
                else
                    echo "Gaming PC is online."
                    break  # Exit the timer loop if the IP is online
                fi
            done
            # Break out of the Bluetooth monitoring loop to restart monitoring
            break
        fi
    done
done
